/* -- JFLAP 4.0 --
 *
 * Copyright information:
 *
 * Susan H. Rodger, Thomas Finley
 * Computer Science Department
 * Duke University
 * April 24, 2003
 * Supported by National Science Foundation DUE-9752583.
 *
 * Copyright (c) 2003
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the author.  The name of the author may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
 
package gui.environment.tag;

/**
 * A tag is simply an interface that can be applied to an object to
 * indicate that it satisfies some sort of property.  The intention is
 * for a tag object to have absolutely no methods to implement.  In
 * this way a tag object functions much like the bitfield vectors of
 * yore for identifying them with particular characteristics, but
 * without the inconvinience of having particular bits tied to certain
 * values that absolutely everybody and his mother had to be made
 * aware of.  A tag object may simply be something that implements
 * <CODE>Tag</CODE> only to indicate that it has no tag.
 * 
 * @see gui.environment.Environment#add
 * 
 * @author Thomas Finley
 */

public interface Tag {
    
}
